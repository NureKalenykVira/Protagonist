<?php
session_start();
require_once 'dbconnect.php';

// Підключення файлу LiqPay SDK
require_once 'libs/LiqPay.php';

if (!isset($_SESSION['userSession']) || !isset($_GET['order_id'])) {
    header("Location: index.php");
    exit;
}

$order_id = $_GET['order_id'];

// Витягніть інформацію про замовлення з бази даних для відображення
$db = new Database();
$orderQuery = $db->getConnection()->prepare("SELECT * FROM orders WHERE id = ?");
$orderQuery->bind_param("i", $order_id);
$orderQuery->execute();
$order = $orderQuery->get_result()->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <title>Оплата</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #4B967D;
        }
        .container {
            background-color: white;
            width: 50%;
            margin: 150px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            text-align: center;
        }
        h2 {
            color: #4B967D;
        }
        p {
            font-size: 18px;
        }
        .payment-form {
            margin-top: 20px;
        }
        .button1 {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #66CDAA;
            color: white;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            font-size: 16px;
        }
        .button1:hover {
            background-color: #5BB894;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Оплата замовлення №<?php echo $order_id; ?></h2>
        <p>Сума до оплати: <?php echo $order['totalAmount']; ?> грн</p>
        
        <div class="payment-form">
            <!-- LiqPay -->
            <?php
            $public_key = 'public_key';
            $private_key = 'private_key';
            $liqpay = new LiqPay($public_key, $private_key);

            $html = $liqpay->cnb_form(array(
                'action'         => 'pay',
                'amount'         => $order['totalAmount'],
                'currency'       => 'UAH',
                'description'    => 'Оплата замовлення №' . $order_id,
                'order_id'       => $order_id,
                'version'        => '3',
                'server_url'     => 'http://localhost:8080/Protagonist/PHP%20Files/success_payment.php',
                'result_url'     => 'http://localhost:8080/Protagonist/PHP%20Files/orderResult.php?order_id=' . $order_id
            ));
            echo $html;
            ?>
        </div>
        <form method="post">
            <button type="submit" name="successful_payment" class="button1">Успішно сплачено</button>
        </form>
    </div>
</body>
</html>

<?php
if (isset($_POST['successful_payment'])) {
    header("Location: /Protagonist/PHP%20Files/orderResult.php?order_id=$order_id");
    exit();
}
?>