<?php
session_start();
require_once 'dbconnect.php';

// Перевірка, чи користувач увійшов у систему
if (!isset($_SESSION['userSession'])) {
    header("Location: index.php");
    exit;
}

// Перевірка наявності параметра orderID
if (!isset($_GET['orderID'])) {
    header("Location: view_orders.php");
    exit;
}

$orderID = $_GET['orderID'];

class Returns {
    private $db;

    public function __construct() {
        $this->db = new Database();
    }

    public function createReturn($orderID, $productID, $returnReason, $userID) {
        $stmt = $this->db->getConnection()->prepare("INSERT INTO returns (orderID, productID, returnReason, returnDate, returnStatus, customerID) VALUES (?, ?, ?, NOW(), 'Очікується', ?)");
        $stmt->bind_param('iisi', $orderID, $productID, $returnReason, $userID);
        return $stmt->execute();
    }

    public function getProductsByOrder($orderID) {
        $stmt = $this->db->getConnection()->prepare("SELECT oi.productID, p.productName FROM orderitems oi JOIN products p ON oi.productID = p.productID WHERE oi.orderID = ?");
        $stmt->bind_param('i', $orderID);
        $stmt->execute();
        return $stmt->get_result();
    }
}

$returns = new Returns();
$products = $returns->getProductsByOrder($orderID);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $productID = $_POST['productID'];
    $returnReason = $_POST['returnReason'];

    if ($returns->createReturn($orderID, $productID, $returnReason, $_SESSION['userSession'])) {
        echo '<script>alert("Запит на повернення успішно створено"); window.location.href="view_orders.php";</script>';
    } else {
        echo '<script>alert("Не вдалося створити запит на повернення"); window.location.href="view_orders.php";</script>';
    }
}

require('header.php');
require('menu.php');
?>

<h2 style="color: black; text-align: center;">Створити запит на повернення</h2>
<form method="post" action="return_order.php?orderID=<?php echo $orderID; ?>" style="width: 50%; margin: 0 auto; background-color: #66CDAA; padding: 20px; border-radius: 10px;">
    <div style="margin-bottom: 10px;">
        <label for="productID" style="display: block; color: black; font-weight: bold;">Товар:</label>
        <select name="productID" id="productID" required style="width: 100%; padding: 10px; border-radius: 5px; border: 1px solid #4B967D;">
            <?php while ($product = $products->fetch_assoc()): ?>
                <option value="<?php echo $product['productID']; ?>"><?php echo $product['productName']; ?></option>
            <?php endwhile; ?>
        </select>
    </div>
    <div style="margin-bottom: 10px;">
        <label for="returnReason" style="display: block; color: black; font-weight: bold;">Причина повернення:</label>
        <textarea name="returnReason" id="returnReason" required style="width: 100%; padding: 10px; border-radius: 5px; border: 1px solid #4B967D;"></textarea>
    </div>
    <div style="text-align: center;">
        <input type="submit" value="Створити запит" style="padding: 10px 20px; border-radius: 5px; background-color: #4B967D; color: white; border: none; cursor: pointer;">
    </div>
</form>

<?php
require('footer.php');
?>