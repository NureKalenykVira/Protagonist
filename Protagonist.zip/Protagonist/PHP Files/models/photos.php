<?php
require_once __DIR__ . '/../functions/sql.php';

function Photo_insert($data) {
    $sql = "INSERT INTO images (title, image_path) VALUES ('".$data['title']."', '".$data['image']."')";
    Sql_exec($sql);
}

function Photos_getAll() {
    $sql = "SELECT * FROM images";
    return Sql_query($sql);
}

?>
