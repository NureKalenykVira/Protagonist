<?php
session_start();
ob_start(); // Початок буферизації виводу
require_once 'dbconnect.php';
require('header.php');
require('menu.php');

class SessionManager {
    public static function redirectToLoginIfNotLoggedIn() {
        if (!isset($_SESSION['userSession'])) {
            echo '<center><h1 style="color: black">Перепрошуємо, для здійснення покупки необхідно увійти або зареєструватися.</h1></center>';
            echo '<center><h3><a id="orderLogin" href="index.php" style="color: #4B967D"> Натисніть тут для входу або реєстрації </a></h3></center>';
            exit;
        } else {
            header("Location: orderResult.php");
            exit;
        }
    }
}

class CartManager {
    public static function checkCart() {
        if (empty($_SESSION['cart'])) {
            echo '<script>alert("Your cart is empty.")</script>';
            echo '<script>window.location="yourcart.php"</script>';
            exit;
        }
    }
}

// Check cart contents
CartManager::checkCart();

// Check user login status and redirect if logged in
SessionManager::redirectToLoginIfNotLoggedIn();

require('footer.php');
ob_end_flush(); // Кінець буферизації і вивід контенту
?>