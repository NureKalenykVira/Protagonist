<?php

class Database {
    private $host = "localhost";
    private $username = "root";
    private $password = "";
    private $database = "sonicTechStore";

    protected $conn;

    public function __construct() {
        $this->connect();
    }

    private function connect() {
        try {
            $this->conn = new mysqli($this->host, $this->username, $this->password, $this->database);
            if ($this->conn->connect_error) {
                throw new Exception("Connection failed: " . $this->conn->connect_error);
            }
        } catch (Exception $e) {
            echo "Connection error: " . $e->getMessage();
            exit;
        }
    }

    public function getConnection() {
        return $this->conn;
    }

    public function closeConnection() {
        if ($this->conn) {
            $this->conn->close();
        }
    }

    public function deleteUser($userId) {
        try {
            $stmt = $this->conn->prepare("DELETE FROM Customers WHERE customerID = ?");
            if (!$stmt) {
                throw new Exception("Prepare statement failed: " . $this->conn->error);
            }
            $stmt->bind_param('i', $userId);
            $stmt->execute();
            if ($stmt->affected_rows === 0) {
                throw new Exception("No rows affected or deletion failed.");
            }
            return true;
        } catch (Exception $e) {
            echo "Error: " . $e->getMessage();
            return false;
        } finally {
            if ($stmt) {
                $stmt->close();
            }
        }
    }
}

$db = new Database();
$conn = $db->getConnection();
$db->closeConnection();

?>