<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>buy</title>
    <link rel="stylesheet" href="style.css">
    <style type="text/css">
        h1 {
            color: white;
            font-size: 24pt;
            text-align: center;
            font-family: arial, sans-serif;
            margin: 0;
            padding: 30px 0;
        }

        /* For menu bar */
        ul.menuBar {
            background-color: #6495ED;
            overflow: hidden;
            list-style-type: none;
            margin: 0;
            padding: 0;
        }
        ul li.menuBar {
            float: left;
            width: 20%;
        }
        li a:active, a:visited, a:link.menuBar {
            color: white;
            display: block;
            padding: 12px;
            text-align: center;
            text-decoration: none;
            font-size: 13pt;
        }
        li a:hover.menuBar {
            background-color: #6495ED;
        }

        /* For footer */
        p.foot {
            color: white;
            font-size: 9pt;
            text-align: center;
            font-family: arial, sans-serif;
            font-weight: bold;
        }

        /* For cart */
        th.cart {
            color: white;
            background-color: #48577D;
            text-align: center;
            padding: 5px;
        }
        td.cart {
            text-align: center;
            background-color: #d3dcf2;
            padding: 10px;
        }

        /* For contact */
        td.contact {
            padding: 10px;
        }

        /* For particular links */
        #login:active, #login:visited, #login:link {
            color: blue;
            text-decoration: none;
            font-size: 13pt;
        }
        #signup:active, #signup:visited, #signup:link {
            color: blue;
            text-decoration: none;
            font-size: 13pt;
        }
        #username:active, #username:visited, #username:link {
            color: black;
            text-decoration: none;
        }
        #logout:active, #logout:visited, #logout:link {
            color: red;
            text-decoration: none;
        }
        #order:active, #order:visited, #order:link {
            color: blue;
            text-decoration: none;
        }
        #orderLogin:active, #orderLogin:visited, #orderLogin:link {
            color: blue;
        }
        #delete:active, #delete:visited, #delete:link {
            color: red;
            text-decoration: none;
        }
        #checkout:active, #checkout:visited, #checkout:link {
            color: red;
            text-decoration: none;
        }
        #continue:active, #continue:visited, #continue:link {
            color: blue;
            text-decoration: none;
        }

        /* For menu bar */
        ul.menuBar {
            background-color: #4B967D;
            overflow: hidden;
            list-style-type: none;
            margin: 0;
            padding: 0;
        }

        ul li.menuBar {
            float: left;
            width: 20%;
        }

        li a:active, a:visited, a:link.menuBar {
            color: white;
            display: block;
            padding: 12px;
            text-align: center;
            text-decoration: none;
            font-size: 13pt;
        }

        li a:hover.menuBar {
            background-color: white;
        }

        /* Styles for form */
        form.selectForm {
            background-color: #4B967D;
            display: inline;
            margin: 1px;
            padding: 0px;
        }

        form.selectForm select {
            color: white;
            padding: 12px;
            text-align: center;
            text-decoration: none;
            font-size: 13pt;
            background-color: #4B967D;
            border: black;
            appearance: none;
        }

        form.selectForm select:hover {
            background-color: #4B967D;
        }
    </style>
</head>
<body>
<div title="container" style="width: 100%; height: 100%;">
    <div title="header" style="width: 100%; background: #66CDAA;">
        <h1>P R O T A G O N I S T</h1>
    </div>
