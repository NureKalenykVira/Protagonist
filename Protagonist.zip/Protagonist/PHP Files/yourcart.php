<?php
session_start();
require_once 'dbconnect.php';

class CartManager {
    private $cart;

    public function __construct() {
        $this->initializeCart();
    }

    private function initializeCart() {
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }
        $this->cart = &$_SESSION['cart'];
    }

    public function displayCartItems() {
        $total = 0;
        $itemCount = 0;

        echo "<table style='width: 100%'>
                <tr>
                    <th class='cart' style='background-color: #4B967D'>Назва</th>
                    <th class='cart' style='background-color: #4B967D'>Кількість</th>
                    <th class='cart' style='background-color: #4B967D'>Вартість</th>
                    <th class='cart' style='background-color: #4B967D'>Сума замовлення</th>
                    <th class='cart' style='background-color: #4B967D'>Видалити</th>
                </tr>";
        
        foreach ($this->cart as $keys => $values) {
            $itemTotal = number_format($values["item_quantity"] * $values["product_price"], 2);
            echo "<tr class='cart'>
                    <td style='background-color: #66CDAA'>{$values['item_name']}</td>
                    <td class='cart' style='background-color: #A3F8DB'>{$values['item_quantity']}</td>
                    <td class='cart' style='background-color: #A3F8DB'>{$values['product_price']} грн</td>
                    <td class='cart' style='background-color: #A3F8DB'>$itemTotal грн</td>
                    <td class='cart' style='background-color: #A3F8DB'><a id='delete' href='shop.php?action=delete&id={$values['product_id']}'><span>X</span></a></td>
                </tr>";
            $total += $values["item_quantity"] * $values["product_price"];
            $itemCount++;
        }
        echo "</table>";

        if ($itemCount == 0) {
            echo "<h3 style='text-align: center; color: black; margin-bottom: 18%'>Кошик наразі порожній, <a href='product.php' style='text-decoration: none; color: #4B967D;'>перейти до покупок</a></h3>";
        }

        return $total;
    }

    public function displayTotal($total) {
        if ($total > 0) {
            $tax = number_format($total * 0.1, 2);
            $totalWithTax = number_format($total * 1.1, 2);
            echo "<div style='text-align: center;'>
                    <p><u>Вартість:</u> $total грн</p>
                    <h3>Загалом до оплати: $total грн</h3>
                    <h2><a id='checkout' href='order_form.php' style='text-decoration: none; color: white; background-color: #4B967D; padding: 10px 20px; border-radius: 5px;'>Купити</a></h2>
                  </div>";
        }
    }
}

function getRecommendation($user_id, $cart_items) {
    $db = new Database();
    
    // Виключити продукти, які вже є в кошику
    $placeholders = implode(',', array_fill(0, count($cart_items), '?'));
    $types = str_repeat('i', count($cart_items));
    $params = array_keys($cart_items);
    
    // Формуємо запит для виключення товарів, які вже є в кошику
    $query = "SELECT p.productID, p.productName, p.productPrice, p.productImage
              FROM Products p
              WHERE p.productID NOT IN ($placeholders)
              ORDER BY RAND()
              LIMIT 1";
    
    $recommendQuery = $db->getConnection()->prepare($query);
    $recommendQuery->bind_param($types, ...$params);
    $recommendQuery->execute();
    return $recommendQuery->get_result()->fetch_assoc();
}

require('header.php');
require('menu.php');

$cartManager = new CartManager();
$total = $cartManager->displayCartItems();
$cartItems = $_SESSION['cart'];
$firstCartItemName = !empty($cartItems) ? reset($cartItems)['item_name'] : ''; // Отримати назву першого товару в кошику

if ($total > 0) {
    $cartManager->displayTotal($total);
    
    // Відображення рекомендацій
    if (isset($_SESSION['userSession'])) {
        $recommendation = getRecommendation($_SESSION['userSession'], $cartItems);
        if ($recommendation) {
            echo "<div style='text-align: center; margin-top: 20px; display: flex; justify-content: center; align-items: flex-start;'>
                    <div style='flex: 1; text-align: center;'>
                        <img src='{$recommendation['productImage']}' alt='{$recommendation['productName']}' style='width: 200px; height: auto;'>
                    </div>
                    <div style='flex: 2; text-align: left;'>
                        <h3>Якщо Вам сподобалась \"{$firstCartItemName}\",<br> то \"{$recommendation['productName']}\" точно для Вас!</h3>
                        <form method='post' action='shop.php?action=add&id={$recommendation['productID']}'>
                            <input type='hidden' name='hidden_name' value='{$recommendation['productName']}'>
                            <input type='hidden' name='hidden_price' value='{$recommendation['productPrice']}'>
                            <input type='hidden' name='quantity' value='1'>
                            <input type='submit' name='add' value='Додати до кошика' style='width: auto; padding: 10px 20px; border-radius: 5px; margin-top: 10px; background-color: #4B967D; color: white; border: none; cursor: pointer; font-size: 16px'>
                        </form>
                    </div>
                  </div>";
        }
    }
}

require('footer.php');
?>