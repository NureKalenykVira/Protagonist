<?php
session_start();
require_once 'dbconnect.php';

class Authentication {
    private $db;

    public function __construct(Database $db) {
        $this->db = $db;
    }

    public function login($username, $password) {
        $username = $this->db->getConnection()->real_escape_string($username);
        $password = $this->db->getConnection()->real_escape_string($password);

        $query = $this->db->getConnection()->query("SELECT customerID, userName, userPassword FROM Customers WHERE userName='$username'");
        $row = $query->fetch_array();
        $count = $query->num_rows;

        if ($count == 1 && password_verify($password, $row['userPassword'])) {
            $_SESSION['userSession'] = $row['customerID'];
            header("Location: success.php");
            exit;
        } else {
            return "<div><h3 style=\"color: red\"> &nbsp; Invalid Username or Password !</h3></div>";
        }
    }
}

if (isset($_SESSION['userSession']) != "") {
    header("Location: success.php");
    exit;
}

$msg = "";

if (isset($_POST['btn-login'])) {
    $auth = new Authentication(new Database());
    $msg = $auth->login($_POST['username'], $_POST['password']);
}

require('header.php');
require('menu.php');
?>

<style>
    .login-container {
        max-width: 400px;
        margin: 0 auto;
        padding: 20px;
        border-radius: 10px;
        background-color: #f4f4f4;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .login-container h2 {
        margin-bottom: 20px;
        color: #333;
    }

    .login-container input {
        width: 100%;
        height: 50px;
        border-radius: 5px;
        margin: 0 0 20px 0;
        padding-left: 15px;
        border: 1px solid #ccc;
        font-size: 16px;
    }

    .login-container button {
        width: 100%;
        height: 50px;
        border-radius: 5px;
        background-color: #66CDAA;
        font-size: 18px;
        color: white;
        border: none;
        cursor: pointer;
    }

    .login-container button:hover {
        background-color: #5bb597;
    }

    .login-container a {
        color: black;
        text-decoration: none;
        font-size: 14px;
    }

    .login-container a:hover {
        text-decoration: underline;
    }
</style>

<div class="login-container">
    <form method="post" id="login-form">
        <h2>Вхід</h2>
        <hr />
        <?php if($msg) echo $msg; ?>
        <div>
            <input type="text" class="form-control" placeholder="Нікнейм" name="username" required />
        </div>
        <div>
            <input type="password" class="form-control" placeholder="Пароль" name="password" required />
        </div>
        <hr />
        <button type="submit" name="btn-login" id="btn-login">Увійти</button>
        <br><br>
        <a id="signup" href="register.php">Ще не маєте акаунту? Зареєструватися!</a>
    </form>
</div>

<?php require('footer.php');

// В кінці вашого коду
if (isset($_SESSION['userSession'])) {
    header("Location: success.php");
    exit;
}
?>