<?php
require 'load_language.php';
?>

<?php

$filePath = 'C:\xampp\htdocs\Protagonist\PHP Files\models\photos.php';
if (file_exists($filePath)) {
    require_once $filePath;
} else {
    echo 'File not found: ' . $filePath;
}

class PageContentManager {
    private $galleryItems;

    public function __construct($galleryItems = []) {
        $this->galleryItems = $galleryItems;
    }

    public function printPhotoGallery() {
        echo '<div class="gallery">';
        foreach ($this->galleryItems as $item) {
            echo '<div class="photo-item">';
            echo '<img src="' . htmlspecialchars($item['image_path']) . '" style="width: 100%; max-width: 400px;" alt="">';
            echo '</div>';
        }
        echo '</div>';
        echo '<br><a href="add.php"></a>';
    }

    public function printWelcomeMessage() {
        echo "<p style=\"text-align: center; color: #111; font-family: 'Aptos', sans-serif; font-size: 30px; font-weight: 300; line-height: 32px; margin: 0 0 30px; text-align: center;\">" . __('welcome') . "</p>";
    }

    public function printDescription() {
        echo "<p style=\"text-align: center; padding-left: 200px; padding-right: 200px;\">" . __('description') . "</p>";
    }

    public function printMainImage() {
        echo "<img src=\"mainpic.png\" style=\"width: 70%; margin-top: 30px\" alt=\"Main Picture\">";
    }
}
?>

<!DOCTYPE html>
<html lang="<?php echo $_SESSION['lang']; ?>">
<head>
    <meta charset="UTF-8">
    <title><?php echo __('title'); ?></title>
    <link rel="stylesheet" href="style.css">
    <style>
        .gallery {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            margin: 20px 0;
        }
        .photo-item {
            margin: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            transition: transform 0.2s;
        }
        .photo-item:hover {
            transform: scale(1.1);
        }
        .photo-item img {
            width: 100%;
            height: auto;
        }
    </style>
</head>
<body>
    <?php require('header.php'); ?>
    <?php require('menu.php'); ?>

    <?php
    $galleryItems = Photos_getAll();
    $contentManager = new PageContentManager($galleryItems);
    $contentManager->printPhotoGallery();
    $contentManager->printWelcomeMessage();
    $contentManager->printDescription();
    $contentManager->printMainImage();
    ?>

    <?php require('footer.php'); ?>
</body>
</html>
