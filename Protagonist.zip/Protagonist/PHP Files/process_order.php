<?php
session_start();
require_once 'dbconnect.php';

if (!isset($_SESSION['userSession'])) {
    header("Location: index.php");
    exit;
}

if (isset($_POST['order'])) {
    $username = $_POST['username'];
    $customerName = $_POST['customerName'];
    $customerAddress = $_POST['customerAddress'];
    $customerPhone = $_POST['customerPhone'];
    $customerEmail = $_POST['customerEmail'];
    $deliveryMethod = $_POST['deliveryMethod'];
    $paymentMethod = $_POST['paymentMethod'];
    $noCall = isset($_POST['noCall']) ? 1 : 0;

    // Збереження інформації про замовлення у базу даних
    $db = new Database();
    $userId = $_SESSION['userSession'];
    
    // Обчислення загальної суми замовлення
    $totalAmount = 0;
    foreach ($_SESSION['cart'] as $item) {
        $totalAmount += $item['item_quantity'] * $item['product_price'];
    }

    $orderQuery = $db->getConnection()->prepare("INSERT INTO Orders (userId, username, customerName, customerAddress, customerPhone, customerEmail, deliveryMethod, paymentMethod, noCall, totalAmount) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $orderQuery->bind_param("isssssssid", $userId, $username, $customerName, $customerAddress, $customerPhone, $customerEmail, $deliveryMethod, $paymentMethod, $noCall, $totalAmount);
    $orderQuery->execute();
    $orderId = $orderQuery->insert_id;

    // Додайте товари до замовлення
    foreach ($_SESSION['cart'] as $item) {
        $itemQuery = $db->getConnection()->prepare("INSERT INTO OrderItems (orderId, productId, quantity, price) VALUES (?, ?, ?, ?)");
        $itemQuery->bind_param("iiid", $orderId, $item['product_id'], $item['item_quantity'], $item['product_price']);
        $itemQuery->execute();
    }

    // Перенаправлення на сторінку оплати або підтвердження замовлення
    if ($paymentMethod == 'card') {
        header("Location: payment.php?order_id=$orderId");
    } else {
        header("Location: orderResult.php?order_id=$orderId");
    }

    exit();
}
?>