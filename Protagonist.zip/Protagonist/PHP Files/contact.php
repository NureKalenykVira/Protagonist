<?php
session_start();

class Database {
    private $host = "localhost";
    private $username = "root";
    private $password = "";
    private $database = "sonicTechStore";
    private $conn;

    public function __construct() {
        $this->connect();
    }

    private function connect() {
        $this->conn = new mysqli($this->host, $this->username, $this->password, $this->database);
        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
    }

    public function closeConnection() {
        $this->conn->close();
    }
}

class FeedbackManager {
    private $db;

    public function __construct() {
        $this->db = new Database();
    }

    public function sendFeedback($to, $subject, $message) {
        // Simulate email sending for example
        // In production, you should use a mailer library like PHPMailer or SwiftMailer
        if (mail($to, $subject, $message)) {
            echo '<script>alert("Successfully sent message")</script>';
            echo '<script>window.location="contact.php"</script>';
        } else {
            echo '<script>alert("Failed to send message")</script>';
        }
        $this->db->closeConnection();
    }
}

require('header.php');
require('menu.php');

if (isset($_POST['submit'])) {
    $feedbackManager = new FeedbackManager();
    $feedbackManager->sendFeedback("sonicTechStore@example.com", $_POST['name'], $_POST['message']);
}
?>

<div align="center" style="margin: 15px;">
<form method="post">
<table class="contact">
    <tr class="contact">
        <td class="contact" colspan="2"><h2>Зворотній зв'язок<h2></td>
    </tr>
    
    <tr class="contact">
        <td class="contact"><b>Ваше ім'я:</b></td>
        <td class="contact"><input style="border-radius: 5px;" type="text" name="name" required></td>
    </tr>

    <tr class="contact">
        <td class="contact"><b>Номер телефону:</b> </td>
        <td class="contact"><input style="border-radius: 5px;" type="text" maxlength="10" required></td>
    </tr>

    <tr class="contact">
        <td class="contact"><b>Адреса електронної пошти:</b> </td>
        <td class="contact"><input style="border-radius: 5px;" type="email" required></td>
    </tr>

    <tr class="contact">
        <td class="contact"><b>Відгук:</b> </td>
        <td class="contact"><textarea style="border-radius: 5px;" rows="10" cols="55" name="message" required></textarea>
    </tr>
    
    <tr class="contact">
        <td class="contact"></td>
        <td class="contact"><input style="border-radius: 5px; background-color: #66CDAA; font-size: 20px" type="submit" name="submit"></td>
    </tr>
</table>
</form>
</div>

<?php require('footer.php'); ?>
