<?php
function sql_connect() {
    $conn = new mysqli('localhost', 'root', '', 'sonictechstore');
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    return $conn;
}

function sql_exec($sql) {
    $conn = sql_connect();
    $conn->query($sql);
    $conn->close();
}

function sql_query($sql) {
    $conn = sql_connect();
    $result = $conn->query($sql);
    $ret = [];
    while ($row = $result->fetch_assoc()) {
        $ret[] = $row;
    }
    $conn->close();
    return $ret;
}