<?php
function file_upload($field) {
    if (empty($_FILES[$field]['name'])) {
        return false;
    }
    $upload_dir = __DIR__ . '/../img/';
    $upload_file = $upload_dir . basename($_FILES[$field]['name']);
    if (move_uploaded_file($_FILES[$field]['tmp_name'], $upload_file)) {
        return 'img/' . $_FILES[$field]['name'];
    } else {
        return false;
    }
}
