<?php
session_start();

class Database {
    private $host = "localhost";
    private $username = "root";
    private $password = "";
    private $database = "sonicTechStore";
    private $conn;

    public function __construct() {
        $this->connect();
    }

    private function connect() {
        $this->conn = new mysqli($this->host, $this->username, $this->password, $this->database);
        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
    }

    public function closeConnection() {
        $this->conn->close();
    }

    public function getUserInfo($userId) {
        $stmt = $this->conn->prepare("SELECT * FROM Customers WHERE customerID = ?");
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    public function deleteUser($userId) {
        $stmt = $this->conn->prepare("DELETE FROM Customers WHERE customerID = ?");
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        return $stmt->affected_rows > 0;  // Returns true if the user was deleted
    }
}

class Customer {
    private $db;
    public $userInfo;

    public function __construct($userId) {
        $this->db = new Database();
        $this->userInfo = $this->db->getUserInfo($userId);
        $this->db->closeConnection();
    }

    public function getInfo() {
        return $this->userInfo;
    }
}

if (!isset($_SESSION['userSession'])) {
    header("Location: index.php");
    exit;
}

$customer = new Customer($_SESSION['userSession']);
$userInfo = $customer->getInfo();

if (!$userInfo['cookies_accepted']) {
    $_SESSION['cookies_accepted'] = false;
}

require('header.php');
require('menu.php');
?>

<head>
    <link rel="stylesheet" href="css/styles.css">
</head>

<h1 style="color: black; text-align: center;">Вітаємо! Вхід виконано успішно.</h1>
<h3 style="text-align: center; text-decoration: none"><a id="order" href="checkout.php" style="color: black">Натисніть тут, щоб перейти до покупок.</a></h3>
<li style="list-style-type: none; float: none;">
    <a id="viewOrders" href="view_orders.php" style="color: #4B967D; margin-top: 30px">
        Переглянути попередні замовлення
    </a>
</li>
<li style="list-style-type: none; float: none;">
    <a id="editProfile" href="edit_profile.php" style="color: #4B967D; margin-top: 10px; margin-bottom: 20px">
        Редагувати профіль
    </a>
</li>
<li style="list-style-type: none; float: none;"><a id="logout" style="color: #4B967D" href="logout.php?logout"><span></span>&nbsp;Вийти</a></li>
<img src="suc.png" style="width: 50%; margin-top: 30px;" alt="Main Picture">
<li style="list-style-type: none; float: none;">
    <a id="deleteAccount" href="?delete=true" style="color: red; margin-top: 30px" onclick="return confirm('Ви впевнені, що хочете видалити свій акаунт? Ця дія незворотна!');">
        Видалити акаунт
    </a>
</li>

<?php
if (isset($_GET['delete'])) {
    $db = new Database();
    if ($db->deleteUser($_SESSION['userSession'])) {
        session_destroy();
        header("Location: index.php");
        exit;
    } else {
        echo '<script>alert("Failed to delete account")</script>';
    }
}

require('footer.php');
?>

<?php if (!isset($_SESSION['cookies_accepted']) || !$_SESSION['cookies_accepted']): ?>
    <div id="cookie-banner" style="position: fixed; bottom: 0; width: 100%; background-color: #4B967D; color: white; text-align: center; padding: 15px;">
        <p>Ми використовуємо файли cookies для покращення вашого досвіду на нашому сайті. Продовжуючи використовувати наш сайт, ви погоджуєтесь на використання файлів cookies.</p>
        <form method="POST" action="cookie_consent.php">
            <button type="submit" style="padding: 10px 20px; background-color: #66CDAA; color: white; border: none; cursor: pointer;">Згоден</button>
        </form>
    </div>
<?php endif; ?>