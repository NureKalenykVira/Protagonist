<?php
session_start();
require_once 'dbconnect.php';

class CartManager {
    public function __construct() {
        if (!isset($_SESSION["cart"])) {
            $_SESSION["cart"] = [];
        }
    }

    public function addItem($item) {
        if ($this->isItemInCart($item['product_id'])) {
            echo '<script>alert("Уже додано до кошика")</script>';
            echo '<script>window.location="product.php"</script>';
        } else {
            $_SESSION["cart"][] = $item;
            // Збереження вподобань користувача
            if (isset($_SESSION['userSession'])) {
                saveUserPreference($_SESSION['userSession'], $item['product_id'], 'added_to_cart');
            }
            echo '<script>alert("Успішно додано до кошика")</script>';
            echo '<script>window.location="product.php"</script>';
        }
    }

    private function isItemInCart($productId) {
        foreach ($_SESSION["cart"] as $item) {
            if ($item['product_id'] === $productId) {
                return true;
            }
        }
        return false;
    }

    public function removeItem($productId) {
        foreach ($_SESSION["cart"] as $key => $item) {
            if ($item["product_id"] == $productId) {
                unset($_SESSION["cart"][$key]);
                echo '<script>alert("Видалено з кошика")</script>';
                echo '<script>window.location="yourcart.php"</script>';
            }
        }
    }
}

function saveUserPreference($user_id, $product_id, $action) {
    $db = new Database();
    $preferenceQuery = $db->getConnection()->prepare("INSERT INTO UserPreferences (userID, productID, action) VALUES (?, ?, ?)");
    $preferenceQuery->bind_param("iis", $user_id, $product_id, $action);
    $preferenceQuery->execute();
}

$cartManager = new CartManager();

if (isset($_POST["add"])) {
    $item_array = array(
        'product_id' => $_GET["id"],
        'item_name' => $_POST["hidden_name"],
        'product_price' => $_POST["hidden_price"],
        'item_quantity' => $_POST["quantity"]
    );
    $cartManager->addItem($item_array);
}

if (isset($_GET["action"]) && $_GET["action"] == "delete") {
    $cartManager->removeItem($_GET["id"]);
}
?>