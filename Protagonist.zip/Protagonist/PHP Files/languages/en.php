<?php
return [
    'welcome' => 'Welcome',
    'cart' => 'Cart',
    'checkout' => 'Checkout',
    'login' => 'Login',
    'register' => 'Register',
    'home' => 'Home',
    'product' => 'Catalog',
    'your_cart' => 'Your Cart',
    'contact' => 'Contact',
    'title' => 'Protagonist Bookstore',
    'description' => 'Protagonist is an online book service. Here readers find books for all tastes: fiction, comics, non-fiction, publications for children, teenagers, and adults in Ukrainian and foreign languages.',
    'language' => 'Language',
    'change_language' => 'Change Language'
];
?>
