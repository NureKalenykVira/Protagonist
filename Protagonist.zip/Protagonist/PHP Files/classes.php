<?php

class Users {
    public $name;
    public $login;
    public $password;

    public function __construct($name, $login, $password) {
        $this->name = $name;
        $this->login = $login;
        $this->password = $password;
    }

    public function getInfo() {
        return "Name: $this->name, Login: $this->login";
    }

    public function __clone() {
        $this->name = "User";
        $this->login = "User";
        $this->password = "qwerty";
    }
}

class SuperUsers extends Users {
    public $character;

    public function __construct($name, $login, $password, $character) {
        parent::__construct($name, $login, $password);
        $this->character = $character;
    }

    public function getInfo() {
        return parent::getInfo() . ", Character: $this->character";
    }

    public function displayCharacter() {
        echo $this->character;
    }
}

$user1 = new Users("Alice", "alice123", "pass123");
$user2 = new Users("Bob", "bob123", "pass456");
$user3 = new Users("Charlie", "charlie123", "pass789");

echo $user1->getInfo() . "\n";
echo $user2->getInfo() . "\n";
echo $user3->getInfo() . "\n";

$user4 = clone $user1;
echo $user4->getInfo() . "\n";

$superUser = new SuperUsers("Dave", "dave123", "secure", "admin");
echo $superUser->getInfo() . "\n";
$superUser->displayCharacter(); 

?>
