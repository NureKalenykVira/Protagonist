<?php
session_start();
require_once 'dbconnect.php';

if (!isset($_SESSION['userSession']) || !isset($_GET['order_id'])) {
    header("Location: index.php");
    exit;
}

$order_id = $_GET['order_id'];

// Витягніть інформацію про замовлення з бази даних для відображення
$db = new Database();
$orderQuery = $db->getConnection()->prepare("SELECT * FROM orders WHERE id = ?");
$orderQuery->bind_param("i", $order_id);
$orderQuery->execute();
$order = $orderQuery->get_result()->fetch_assoc();

// Оновлений запит для отримання товарів замовлення
$itemQuery = $db->getConnection()->prepare("SELECT oi.*, p.productName FROM orderItems oi JOIN products p ON oi.productId = p.productID WHERE oi.orderId = ?");
$itemQuery->bind_param("i", $order_id);
$itemQuery->execute();
$items = $itemQuery->get_result();
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <title>Підтвердження замовлення</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #4B967D;
        }
        .container {
            background-color: white;
            width: 50%;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
        }
        table {
            width: 100%;
            margin-bottom: 20px;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ddd;
        }
        th {
            background-color: #4B967D;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        h2 {
            color: #4B967D;
        }
        p {
            font-size: 18px;
        }
        .button-container {
            text-align: center;
            margin-top: 20px;
        }
        .button {
            background-color: #4B967D;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
        }
        .button:hover {
            background-color: #66CDAA;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Підтвердження замовлення №<?php echo $order_id; ?></h2>
        <p>Нікнейм: <?php echo $order['username']; ?></p>
        <p>ПІБ: <?php echo $order['customerName']; ?></p>
        <p>Адреса: <?php echo $order['customerAddress']; ?></p>
        <p>Номер телефону: <?php echo $order['customerPhone']; ?></p>
        <p>Електронна пошта: <?php echo $order['customerEmail']; ?></p>
        <p>Спосіб доставки: <?php echo $order['deliveryMethod']; ?></p>
        <p>Спосіб оплати: <?php echo $order['paymentMethod']; ?></p>
        <p>Можна не телефонувати для підтвердження: <?php echo $order['noCall'] ? 'Так' : 'Ні'; ?></p>

        <h3>Товари замовлення:</h3>
        <table>
            <tr>
                <th>Назва</th>
                <th>Кількість</th>
                <th>Вартість</th>
                <th>Сума замовлення</th>
            </tr>
            <?php
            while ($item = $items->fetch_assoc()) {
                $itemTotal = number_format($item["quantity"] * $item["price"], 2);
                echo "<tr>
                        <td>{$item['productName']}</td>
                        <td>{$item['quantity']}</td>
                        <td>{$item['price']} грн</td>
                        <td>$itemTotal грн</td>
                    </tr>";
            }
            ?>
        </table>

        <h3>Сума до оплати: <?php echo $order['totalAmount']; ?> грн</h3>
        <div class="button-container">
            <a href="home.php" class="button">Продовжити покупки</a>
        </div>
    </div>
</body>
</html>

<?php
// Очистити кошик після оформлення замовлення
unset($_SESSION['cart']);
?>
