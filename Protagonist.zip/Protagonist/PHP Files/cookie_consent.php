<?php
session_start();
require_once 'dbconnect.php';

class ConsentManager {
    private $db;

    public function __construct(Database $db) {
        $this->db = $db;
    }

    public function updateConsent($userId) {
        $stmt = $this->db->getConnection()->prepare("UPDATE Customers SET cookies_accepted = 1 WHERE customerID = ?");
        $stmt->bind_param('i', $userId);
        return $stmt->execute();
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_SESSION['userSession'])) {
    $db = new Database();
    $consentManager = new ConsentManager($db);
    if ($consentManager->updateConsent($_SESSION['userSession'])) {
        setcookie('cookies_accepted', 'true', time() + (86400 * 365), "/"); // Встановлює cookie на 1 рік
        $_SESSION['cookies_accepted'] = true; // Зберігає згоду в сесії
        header("Location: success.php"); // Перенаправлення на сторінку успіху після згоди
        exit;
    }
    $db->closeConnection();
}
?>
