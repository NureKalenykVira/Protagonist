	<?php ?>
	<div title="footer" style="width:100%;height:20%;margin-top:5%;background:#59B294;padding: 15px 10px;text-align: center;">
		<p style="color:white; padding-top:15px; margin: 10px 10px 0px 10px">Protagonist Book Store.</p>
		<p style="color:white; padding-top:5px">вул. Сумська 25, Харків, Україна</p>
		<p style="color:white; padding-top:5px">© Protagonist 2024. Усі права захищено</p>			
	</div>		
</div>
</body>
</html>