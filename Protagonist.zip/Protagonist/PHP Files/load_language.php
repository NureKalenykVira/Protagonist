<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['lang'])) {
    $_SESSION['lang'] = 'ua'; // Значення за замовчуванням
}

if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
    // Перенаправлення на ту ж сторінку без параметра lang у URL
    $redirect_url = strtok($_SERVER["REQUEST_URI"], '?');
    header("Location: $redirect_url");
    exit;
}

$lang = $_SESSION['lang'];
$lang_file = __DIR__ . "/languages/{$lang}.php"; // Коректне формування шляху до файлу мови

if (file_exists($lang_file)) {
    $lang_data = include($lang_file);
} else {
    $lang_data = include(__DIR__ . "/languages/ua.php"); // Значення за замовчуванням, якщо файл не знайдено
}

if (!function_exists('__')) {
    function __($key) {
        global $lang_data;
        return $lang_data[$key] ?? $key;
    }
}
?>
