<?php
session_start();
require_once 'dbconnect.php';

if (!isset($_SESSION['userSession'])) {
    header("Location: index.php");
    exit;
}

class Orders {
    private $db;

    public function __construct() {
        $this->db = new Database();
    }

    public function getOrdersByUser($userId) {
        $stmt = $this->db->getConnection()->prepare("SELECT * FROM orders WHERE customerName = (SELECT customerName FROM Customers WHERE customerID = ?)");
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        return $stmt->get_result();
    }
}

class Returns {
    private $db;

    public function __construct() {
        $this->db = new Database();
    }

    public function getReturnsByUser($userId) {
        $stmt = $this->db->getConnection()->prepare("SELECT * FROM returns WHERE customerID = ?");
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        return $stmt->get_result();
    }
}

$orders = new Orders();
$userOrders = $orders->getOrdersByUser($_SESSION['userSession']);

$returns = new Returns();
$userReturns = $returns->getReturnsByUser($_SESSION['userSession']);

require('header.php');
require('menu.php');
?>

<h2 style="color: black; text-align: center;">Ваші попередні замовлення</h2>

<?php if ($userOrders->num_rows > 0): ?>
    <table style='width: 100%; text-align: left; border-collapse: collapse; margin-bottom: 30px;'>
        <tr>
            <th style='background-color: #4B967D; padding: 10px; color: white;'>Номер замовлення</th>
            <th style='background-color: #4B967D; padding: 10px; color: white;'>ПІБ</th>
            <th style='background-color: #4B967D; padding: 10px; color: white;'>Адреса</th>
            <th style='background-color: #4B967D; padding: 10px; color: white;'>Номер телефону</th>
            <th style='background-color: #4B967D; padding: 10px; color: white;'>Електронна пошта</th>
            <th style='background-color: #4B967D; padding: 10px; color: white;'>Спосіб доставки</th>
            <th style='background-color: #4B967D; padding: 10px; color: white;'>Спосіб оплати</th>
            <th style='background-color: #4B967D; padding: 10px; color: white;'>Сума до оплати</th>
            <th style='background-color: #4B967D; padding: 10px; color: white;'>Дата замовлення</th>
            <th style='background-color: #4B967D; padding: 10px; color: white;'>Дія</th>
        </tr>
        <?php
        while ($order = $userOrders->fetch_assoc()) {
            echo "<tr style='background-color: #66CDAA;'>";
            echo "<td style='padding: 10px; border: 1px solid #4B967D;'>{$order['id']}</td>";
            echo "<td style='padding: 10px; border: 1px solid #4B967D;'>{$order['customerName']}</td>";
            echo "<td style='padding: 10px; border: 1px solid #4B967D;'>{$order['customerAddress']}</td>";
            echo "<td style='padding: 10px; border: 1px solid #4B967D;'>{$order['customerPhone']}</td>";
            echo "<td style='padding: 10px; border: 1px solid #4B967D;'>{$order['customerEmail']}</td>";
            echo "<td style='padding: 10px; border: 1px solid #4B967D;'>{$order['deliveryMethod']}</td>";
            echo "<td style='padding: 10px; border: 1px solid #4B967D;'>{$order['paymentMethod']}</td>";
            echo "<td style='padding: 10px; border: 1px solid #4B967D;'>{$order['totalAmount']} грн</td>";
            echo "<td style='padding: 10px; border: 1px solid #4B967D;'>{$order['orderDate']}</td>";
            echo "<td style='padding: 10px; border: 1px solid #4B967D;'><a href='return_order.php?orderID={$order['id']}' style='text-decoration: none; color: white; background-color: #4B967D; padding: 5px 10px; border-radius: 5px;'>Повернути</a></td>";
            echo "</tr>";
        }
        ?>
    </table>
<?php else: ?>
    <h3 style="text-align: center; color: black;">На жаль, наразі Вами не було здійснено жодного замовлення</h3>
    <div style="text-align: center; margin-top: 20px; margin-bottom: 30px;">
        <a href="product.php" style="text-decoration: none; color: white; background-color: #4B967D; padding: 10px 20px; border-radius: 5px;">Перейти до покупок</a>
    </div>
<?php endif; ?>

<?php if ($userReturns->num_rows > 0): ?>
    <h2 style="color: black; text-align: center;">Ваші повернення</h2>
    <table style='width: 100%; text-align: left; border-collapse: collapse;'>
        <tr>
            <th style='background-color: #4B967D; padding: 10px; color: white;'>Номер повернення</th>
            <th style='background-color: #4B967D; padding: 10px; color: white;'>Номер замовлення</th>
            <th style='background-color: #4B967D; padding: 10px; color: white;'>Номер товару</th>
            <th style='background-color: #4B967D; padding: 10px; color: white;'>Причина повернення</th>
            <th style='background-color: #4B967D; padding: 10px; color: white;'>Дата повернення</th>
            <th style='background-color: #4B967D; padding: 10px; color: white;'>Статус повернення</th>
        </tr>
        <?php
        while ($return = $userReturns->fetch_assoc()) {
            echo "<tr style='background-color: #66CDAA;'>";
            echo "<td style='padding: 10px; border: 1px solid #4B967D;'>{$return['returnID']}</td>";
            echo "<td style='padding: 10px; border: 1px solid #4B967D;'>{$return['orderID']}</td>";
            echo "<td style='padding: 10px; border: 1px solid #4B967D;'>{$return['productID']}</td>";
            echo "<td style='padding: 10px; border: 1px solid #4B967D;'>{$return['returnReason']}</td>";
            echo "<td style='padding: 10px; border: 1px solid #4B967D;'>{$return['returnDate']}</td>";
            echo "<td style='padding: 10px; border: 1px solid #4B967D;'>{$return['returnStatus']}</td>";
            echo "</tr>";
        }
        ?>
    </table>
<?php endif; ?>

<?php
require('footer.php');
?>