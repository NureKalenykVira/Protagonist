<?php
session_start();
require_once 'dbconnect.php';

class CustomSessionHandler {
    public function __construct() {
        $this->checkSession();
    }

    private function checkSession() {
        if (!isset($_SESSION['userSession']) && !isset($_GET['logout'])) {
            header("Location: index.php");
            exit;
        } elseif (!empty($_SESSION['userSession']) && !isset($_GET['logout'])) {
            header("Location: home.php");
            exit;
        }
    }

    public function logout() {
        if (isset($_GET['logout'])) {
            // Unset all of the session variables.
            $_SESSION = array();

            // If it's desired to kill the session, also delete the session cookie.
            if (ini_get("session.use_cookies")) {
                $params = session_get_cookie_params();
                setcookie(session_name(), '', time() - 42000,
                    $params["path"], $params["domain"],
                    $params["secure"], $params["httponly"]
                );
            }

            // Finally, destroy the session.
            session_destroy();
            header("Location: index.php");
            exit;
        }
    }
}

$sessionHandler = new CustomSessionHandler();
$sessionHandler->logout();

require('header.php');
require('menu.php');
// Page specific content goes here
require('footer.php');
?>
