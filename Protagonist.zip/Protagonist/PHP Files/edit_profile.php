<?php
session_start();
require_once 'dbconnect.php';

// Перевірка чи користувач увійшов в систему
if (!isset($_SESSION['userSession'])) {
    header("Location: index.php");
    exit;
}

class UserManager {
    private $db;

    public function __construct(Database $db) {
        $this->db = $db;
    }

    public function getUserData($userId) {
        $stmt = $this->db->getConnection()->prepare("SELECT * FROM Customers WHERE customerID = ?");
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    public function updateUser($userId, $userData) {
        $userName = $this->db->getConnection()->real_escape_string($userData['username']);
        $customerName = $this->db->getConnection()->real_escape_string($userData['customerName']);
        $customerAddress = $this->db->getConnection()->real_escape_string($userData['customerAddress']);
        $customerPhone = $this->db->getConnection()->real_escape_string($userData['customerPhone']);
        $customerEmail = $this->db->getConnection()->real_escape_string($userData['customerEmail']);
        
        // Якщо новий пароль не введено, не змінюємо його
        if (!empty($userData['password'])) {
            $hashed_password = password_hash($userData['password'], PASSWORD_DEFAULT);
            $query = "UPDATE Customers SET userName=?, customerName=?, customerAddress=?, customerPhone=?, customerEmail=?, userPassword=? WHERE customerID=?";
            $stmt = $this->db->getConnection()->prepare($query);
            $stmt->bind_param('ssssssi', $userName, $customerName, $customerAddress, $customerPhone, $customerEmail, $hashed_password, $userId);
        } else {
            $query = "UPDATE Customers SET userName=?, customerName=?, customerAddress=?, customerPhone=?, customerEmail=? WHERE customerID=?";
            $stmt = $this->db->getConnection()->prepare($query);
            $stmt->bind_param('sssssi', $userName, $customerName, $customerAddress, $customerPhone, $customerEmail, $userId);
        }
        
        return $stmt->execute();
    }
}

$msg = "";
$db = new Database();
$userManager = new UserManager($db);
$userData = $userManager->getUserData($_SESSION['userSession']);

if (isset($_POST['btn-save'])) {
    if ($_POST['password'] === $_POST['confirm_password']) {
        $updateData = [
            'username' => $_POST['username'],
            'customerName' => $_POST['customerName'],
            'customerAddress' => $_POST['customerAddress'],
            'customerPhone' => $_POST['customerPhone'],
            'customerEmail' => $_POST['customerEmail'],
            'password' => $_POST['password'] // Якщо поле порожнє, пароль не буде змінено
        ];
        if ($userManager->updateUser($_SESSION['userSession'], $updateData)) {
            $msg = "<div><h3 style=\"color: green\"> &nbsp; Профіль оновлено успішно!</h3></div>";
        } else {
            $msg = "<div><h3 style=\"color: red\"> &nbsp; Помилка при оновленні профілю!</h3></div>";
        }
    } else {
        $msg = "<div><h3 style=\"color: red\"> &nbsp; Паролі не співпадають!</h3></div>";
    }
}

require('header.php');
require('menu.php');
?>

<style>
    .edit-profile-container {
        max-width: 400px;
        margin: 0 auto;
        padding: 20px;
        border-radius: 10px;
        background-color: #f4f4f4;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .edit-profile-container h2 {
        margin-bottom: 20px;
        color: #333;
    }

    .edit-profile-container input {
        width: 100%;
        height: 50px;
        border-radius: 5px;
        margin: 0 0 20px 0;
        padding-left: 15px;
        border: 1px solid #ccc;
        font-size: 16px;
    }

    .edit-profile-container button {
        width: 100%;
        height: 50px;
        border-radius: 5px;
        background-color: #66CDAA;
        font-size: 18px;
        color: white;
        border: none;
        cursor: pointer;
    }

    .edit-profile-container button:hover {
        background-color: #5bb597;
    }

    .edit-profile-container a {
        color: black;
        text-decoration: none;
        font-size: 14px;
    }

    .edit-profile-container a:hover {
        text-decoration: underline;
    }
</style>

<div class="edit-profile-container">
    <form method="post" id="edit-profile-form">
        <h2>Редагування профілю</h2>
        <hr />
        <?php if (isset($msg)) { echo $msg; } ?>
        <!-- Поля редагування профілю -->
        <div>
            <input type="text" class="form-control" placeholder="Нікнейм" name="username" value="<?php echo $userData['userName']; ?>" required />
        </div>
        <div>
            <input type="text" class="form-control" placeholder="ПІБ" name="customerName" value="<?php echo $userData['customerName']; ?>" required />
        </div>
        <div>
            <input type="text" class="form-control" placeholder="Адреса" name="customerAddress" value="<?php echo $userData['customerAddress']; ?>" required />
        </div>
        <div>
            <input type="text" class="form-control" placeholder="Номер телефону" name="customerPhone" value="<?php echo $userData['customerPhone']; ?>" required />
        </div>
        <div>
            <input type="email" class="form-control" placeholder="Електронна пошта" name="customerEmail" value="<?php echo $userData['customerEmail']; ?>" required />
        </div>
        <div>
            <input type="password" class="form-control" placeholder="Новий пароль (залиште порожнім, якщо не змінюєте)" name="password" />
        </div>
        <div>
            <input type="password" class="form-control" placeholder="Підтвердіть новий пароль" name="confirm_password" />
        </div>
        <hr />
        <button type="submit" class="btn btn-default" name="btn-save">Зберегти зміни</button>
    </form>
</div>

<?php require('footer.php'); ?>
