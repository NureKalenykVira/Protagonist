<?php
session_start();
require_once 'dbconnect.php';

if (!isset($_SESSION['userSession'])) {
    header("Location: index.php");
    exit;
}

class UserManager {
    private $db;

    public function __construct(Database $db) {
        $this->db = $db;
    }

    public function getUserData($userId) {
        $stmt = $this->db->getConnection()->prepare("SELECT * FROM Customers WHERE customerID = ?");
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }
}

$db = new Database();
$userManager = new UserManager($db);
$userData = $userManager->getUserData($_SESSION['userSession']);
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <title>Оформлення замовлення</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #4B967D;
        }
        form {
            background-color: white;
            width: 50%;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
        }
        h2, h3 {
            text-align: center;
        }
        div {
            margin-bottom: 10px;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input, select, button {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        button {
            background-color: #66CDAA;
            border: none;
            color: white;
            cursor: pointer;
        }
        button:hover {
            background-color: #5BB894;
        }
        .checkbox-container {
            display: flex;
            align-items: center;
            font-size: 12px;
        }
        .checkbox-container input {
            width: auto;
            margin-right: 10px;
        }
    </style>
    <script>
        function updateFormAction() {
            var paymentMethod = document.querySelector('select[name="paymentMethod"]').value;
            var form = document.querySelector('form');
            
            if (paymentMethod === 'cash') {
                form.action = 'process_order.php?direct=1';
            } else {
                form.action = 'process_order.php';
            }
        }
    </script>
</head>
<body>
    <form method="post" action="process_order.php" onsubmit="updateFormAction()">
        <h2>Оформлення замовлення</h2>
        
        <div>
            <label for="username">Нікнейм:</label>
            <input type="text" id="username" name="username" value="<?php echo $userData['userName']; ?>" required>
        </div>
        
        <div>
            <label for="customerName">ПІБ:</label>
            <input type="text" id="customerName" name="customerName" value="<?php echo $userData['customerName']; ?>" required>
        </div>
        
        <div>
            <label for="customerAddress">Адреса:</label>
            <input type="text" id="customerAddress" name="customerAddress" value="<?php echo $userData['customerAddress']; ?>" required>
        </div>
        
        <div>
            <label for="customerPhone">Номер телефону:</label>
            <input type="text" id="customerPhone" name="customerPhone" value="<?php echo $userData['customerPhone']; ?>" required>
        </div>
        
        <div>
            <label for="customerEmail">Електронна пошта:</label>
            <input type="email" id="customerEmail" name="customerEmail" value="<?php echo $userData['customerEmail']; ?>" required>
        </div>
        
        <h3>Вибір способу доставки:</h3>
        <div>
            <select name="deliveryMethod" required>
                <option value="новапошта-відділення">Нова Пошта (відділення)</option>
                <option value="новапошта-поштомат">Нова Пошта (поштомат)</option>
                <option value="укрпошта">Укр Пошта</option>
                <option value="кур'єр">Доставка кур'єром за адресою</option>
            </select>
        </div>
        
        <h3>Вибір способу оплати:</h3>
        <div>
            <select name="paymentMethod" required onchange="updateFormAction()">
                <option value="card">Оплатити картою</option>
                <option value="cash">Оплатити при отриманні</option>
            </select>
        </div>
        
        <div class="checkbox-container">
            <input type="checkbox" id="noCall" name="noCall">
            <label for="noCall">Можна не телефонувати мені для підтвердження замовлення</label>
        </div>
        
        <div>
            <button type="submit" name="order">Купити</button>
        </div>
    </form>
</body>
</html>
