<?php
require 'load_language.php';
?>

<!-- menu -->
<head>
  <meta name="viewport" content="width=device-width">
  <style>
    .wrap {
      margin-top: -3px;
    }

    .lang-menu {
      position: relative;
      display: inline-block;
    }

    .lang-menu img {
      width: 30px;
      height: 30px;
      cursor: pointer;
      margin: 20px;
    }

    .lang-menu-content {
      display: none;
      position: absolute;
      background-color: #4B967D;
      min-width: 160px;
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
      z-index: 1;
    }

    .lang-menu-content a {
      color: white;
      padding: 12px 16px;
      text-decoration: none;
      display: block;
    }

    .lang-menu-content a:hover {
      background-color: #66CDAA;
    }

    .lang-menu:hover .lang-menu-content {
      display: block;
    }
  </style>
</head>
<div class="wrap" style="margin-top:-3px">
<nav>
  <ul class="primary" style="background-color: #4B967D; list-style-type: none; padding: 0; font-family: 'Aptos', sans-serif; color: white; font-size: 16px">
    <li style="padding: 10px 0;">
      <a href="home.php" style="font-family: 'Aptos', sans-serif; color: white;"><?php echo __('home'); ?></a>
    </li>
    <li style="padding: 10px 0;">
      <a href="product.php" style="color: white;"><?php echo __('product'); ?></a>
    </li>
    <li style="padding: 10px 0;">
      <a href="yourcart.php" style="color: white;"><?php echo __('your_cart'); ?></a>
    </li>
    <li style="padding: 10px 0;">
      <a href="index.php" style="color: white;"><?php echo __('login'); ?></a>
    </li>
    <li style="padding: 10px 0;">
      <a href="contact.php" style="color: white;"><?php echo __('contact'); ?></a>
    </li>
    <li style="padding: 10px 0;">
    <li class="lang-menu">
        <img src="lang_img_white.png" alt="Language">
        <div class="lang-menu-content">
          <a href="?lang=en" <?php echo $_SESSION['lang'] == 'en' ? 'style="background-color: #66CDAA;"' : ''; ?>>English</a>
          <a href="?lang=ua" <?php echo $_SESSION['lang'] == 'ua' ? 'style="background-color: #66CDAA;"' : ''; ?>>Українська</a>
        </div>
      </li>
    </li>
  </ul>
</nav>
</div>