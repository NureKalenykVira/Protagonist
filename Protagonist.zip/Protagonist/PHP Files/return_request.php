<?php
session_start();
require_once 'dbconnect.php';

if (!isset($_SESSION['userSession'])) {
    header("Location: index.php");
    exit;
}

if (isset($_POST['submit_return'])) {
    $db = new Database();
    $orderID = $_POST['orderID'];
    $productID = $_POST['productID'];
    $customerID = $_SESSION['userSession'];
    $returnReason = $_POST['returnReason'];
    $returnStatus = 'Pending';

    $stmt = $db->getConnection()->prepare("INSERT INTO returns (orderID, productID, customerID, returnReason, returnStatus) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param('iiiss', $orderID, $productID, $customerID, $returnReason, $returnStatus);
    $stmt->execute();

    echo "<p>Ваш запит на повернення успішно створено.</p>";
}
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <title>Запит на повернення</title>
</head>
<body>
    <h2>Запит на повернення</h2>
    <form method="post" action="return_request.php">
        <label for="orderID">Номер замовлення:</label>
        <input type="text" id="orderID" name="orderID" required><br><br>
        
        <label for="productID">Номер товару:</label>
        <input type="text" id="productID" name="productID" required><br><br>
        
        <label for="returnReason">Причина повернення:</label>
        <textarea id="returnReason" name="returnReason" required></textarea><br><br>
        
        <input type="submit" name="submit_return" value="Відправити запит">
    </form>
</body>
</html>
