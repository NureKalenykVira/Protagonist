<?php
session_start();

class Database {
    private $host = "localhost";
    private $username = "root";
    private $password = "";
    private $database = "sonicTechStore";

    protected $conn;

    public function __construct() {
        $this->connect();
    }

    private function connect() {
        $this->conn = new mysqli($this->host, $this->username, $this->password, $this->database);
        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
    }

    public function getConnection() {
        return $this->conn;
    }

    public function closeConnection() {
        if ($this->conn) {
            $this->conn->close();
        }
    }
}

class Product {
    private $db;

    public function __construct() {
        $this->db = new Database();
    }

    public function getAllProducts() {
        $conn = $this->db->getConnection();
        $query = "SELECT * FROM Products ORDER BY productID ASC";
        $result = $conn->query($query);
        $products = [];  
        while ($row = $result->fetch_assoc()) { 
            $products[] = $row;  
        }
        $this->db->closeConnection();
        return $products;  // Повертаємо масив усіх продуктів
    }
}

require('header.php');
require('menu.php');

$product = new Product();
$products = $product->getAllProducts();

if (count($products) > 0) { 
    foreach ($products as $row) {
        ?>
        <div>
            <form method="post" action="shop.php?action=add&id=<?php echo $row["productID"]; ?>">
                <div style="border: 1px solid #eaeaec; margin: -1px 19px 3px -1px; box-shadow: 0 1px 2px rgba(0,0,0,0.05); padding:10px;" align="center">
                    <img src="<?php echo $row["productImage"]; ?>" width="15%">
                    <h5><?php echo $row["productName"]; ?></h5>
                    <h5><?php echo $row["productPrice"]; ?> грн</h5>
                    <input type="number" name="quantity" value="1" style="width: 10%; height: 5%; border-radius: 5px; margin: 0 0 10px 0">
                    <input type="hidden" name="hidden_name" value="<?php echo $row["productName"]; ?>">
                    <input type="hidden" name="hidden_price" value="<?php echo $row["productPrice"]; ?>">
                    <input type="submit" name="add" value="Купити" style="width: 10%; height: 5%; border-radius: 5px; margin: 0 0 10px 0; background-color: #66CDAA">
                </div>
            </form>
        </div>
        <?php
    }
}

require('footer.php');
?>
