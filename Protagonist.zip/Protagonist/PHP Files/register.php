<?php
session_start();
require_once 'dbconnect.php';

class UserManager {
    private $db;

    public function __construct(Database $db) {
        $this->db = $db;
    }

    public function registerUser($userData) {
        $userName = $this->db->getConnection()->real_escape_string($userData['username']);
        $userPass = $this->db->getConnection()->real_escape_string($userData['password']);
        $customerName = $this->db->getConnection()->real_escape_string($userData['customerName']);
        $customerAddress = $this->db->getConnection()->real_escape_string($userData['customerAddress']);
        $customerPhone = $this->db->getConnection()->real_escape_string($userData['customerPhone']);
        $customerEmail = $this->db->getConnection()->real_escape_string($userData['customerEmail']);

        $hashed_password = password_hash($userPass, PASSWORD_DEFAULT);

        $check_username = $this->db->getConnection()->query("SELECT userName FROM Customers WHERE userName='$userName'");
        $check_email = $this->db->getConnection()->query("SELECT customerEmail FROM Customers WHERE customerEmail='$customerEmail'");
        $count = $check_email->num_rows + $check_username->num_rows;

        if ($count == 0) {
            $query = "INSERT INTO Customers(userName, userPassword, customerName, customerAddress, customerPhone, customerEmail)
                      VALUES('$userName', '$hashed_password', '$customerName', '$customerAddress', '$customerPhone', '$customerEmail')";

            if ($this->db->getConnection()->query($query)) {
                return "<div><h3 style=\"color: green\"> &nbsp; Успішно зарєстровано!</h3></div>";
            } else {
                return "<div><h3 style=\"color: red\"> &nbsp; Виникла помилка в процесі реєстрації!</h3></div>";
            }
        } else {
            return "<div><h3 style=\"color: red\"> &nbsp; Ім'я або пошта вже зареєстровані!</h3></div>";
        }
    }
}

if (isset($_SESSION['userSession']) != "") {
    header("Location: success.php");
    exit;
}

$msg = "";
$db = new Database();

if(isset($_POST['btn-signup'])) {
    $userManager = new UserManager($db);
    $userData = [
        'username' => $_POST['username'],
        'password' => $_POST['password'],
        'customerName' => $_POST['customerName'],
        'customerAddress' => $_POST['customerAddress'],
        'customerPhone' => $_POST['customerPhone'],
        'customerEmail' => $_POST['customerEmail']
    ];
    $msg = $userManager->registerUser($userData);
}

require('header.php');
require('menu.php');
?>

<style>
    .register-container {
        max-width: 400px;
        margin: 0 auto;
        padding: 20px;
        border-radius: 10px;
        background-color: #f4f4f4;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .register-container h2 {
        margin-bottom: 20px;
        color: #333;
    }

    .register-container input {
        width: 100%;
        height: 50px;
        border-radius: 5px;
        margin: 0 0 20px 0;
        padding-left: 15px;
        border: 1px solid #ccc;
        font-size: 16px;
    }

    .register-container button {
        width: 100%;
        height: 50px;
        border-radius: 5px;
        background-color: #66CDAA;
        font-size: 18px;
        color: white;
        border: none;
        cursor: pointer;
    }

    .register-container button:hover {
        background-color: #5bb597;
    }

    .register-container a {
        color: black;
        text-decoration: none;
        font-size: 14px;
    }

    .register-container a:hover {
        text-decoration: underline;
    }
</style>

<div class="register-container">
    <form method="post" id="register-form">
        <h2>Реєстрація</h2>
        <hr />
        <?php if (isset($msg)) { echo $msg; } ?>
        <div>
            <input type="text" class="form-control" placeholder="Нікнейм" name="username" required />
        </div>
        <div>
            <input type="password" class="form-control" placeholder="Пароль" name="password" required />
        </div>
        <div>
            <input type="email" class="form-control" placeholder="Електронна пошта" name="customerEmail" required />
        </div>
        <div>
            <input type="text" class="form-control" placeholder="ПІБ" name="customerName" required />
        </div>
        <div>
            <input type="text" class="form-control" placeholder="Адреса" name="customerAddress" required />
        </div>
        <div>
            <input type="text" class="form-control" placeholder="Номер телефону" name="customerPhone" required />
        </div>
        <hr />
        <button type="submit" class="btn btn-default" name="btn-signup">Створити акаунт</button>
        <br><br>
        <a href="index.php" class="btn btn-default">Вже маєте акаунт? Увійти</a>
    </form>
</div>

<?php require('footer.php');

// В кінці вашого коду
if (isset($_SESSION['userSession'])) {
    header("Location: success.php");
    exit;
}
?>
