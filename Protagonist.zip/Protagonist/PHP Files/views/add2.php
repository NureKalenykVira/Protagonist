<!DOCTYPE HTML>
<html>
<head>
    <title>Добавить изображение</title>
</head>
<body>
    <form action="/controllers/add.php" method="POST" enctype="multipart/form-data">
        <label for="title">Название:</label>
        <input type="text" id="title" name="title" required><br><br>
        <label for="image">Файл:</label>
        <input type="file" id="image" name="image" required><br><br>
        <input type="submit" value="Submit">
    </form>
</body>
</html>