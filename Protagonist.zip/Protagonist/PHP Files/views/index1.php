<!DOCTYPE HTML>
<html>
<head>
    <title>Головна</title>
</head>
<body>
    <table border="1">
        <tr>
            <th>Назва</th>
            <th>Фото</th>
        </tr>
        <?php foreach ($items as $item) : ?>
        <tr>
            <td><?php echo htmlspecialchars($item['title']); ?></td>
            <td><img src="<?php echo htmlspecialchars($item['patch']); ?>" style="max-width: 200px;" alt=""></td>
        </tr>
        <?php endforeach; ?>
    </table>
    <br>
    <a href="add.php">Додати фото</a>
</body>
</html>
