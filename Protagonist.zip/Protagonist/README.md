# PHP-MySQL-Shopping-Website
This is a website written in PHP &amp; MySQL that works similarly like Amazon and other popular shopping website. It has a relational database for users and products. The users will have the ability to search for items, add-to-cart, review-cart and check out.
